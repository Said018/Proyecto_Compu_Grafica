Here is a 3d-model of a beamer, modeled and textured in Blender.

- main textures 1024px

- 464 vertices 
- 280 polygons 
- 526 triangles


Time-lapse video: https://www.youtube.com/watch?v=-dj1Vcm3vvs

3d-Preview on Sketchfab : https://sketchfab.com/models/c1c504db02e445d3bcd421cdc4d063d2



� DennisH2010

Sketchfab.com: https://sketchfab.com/dennish2010/recent

Verold.com: http://studio.verold.com/users/53199fa416c3570200000603/filter/mine

Blog : http://3dartdh.wordpress.com/

YouTube-Channel: https://www.youtube.com/user/DennisH2010